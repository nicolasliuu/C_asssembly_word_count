TODO: add information about contributions of team member(s)

Nicolas: 
- wc_readnext, wc_tolower, wc_trim_non_alpha, wc_dict_find_or_insert, wc_find_or_insert
basic main implementation in C
is_alpha function in assembly, debugging on wc_str_compare assembly

Jayden: 
wc_hash, wc_str_compare, wc_str_copy, wc_isspace, wc_isalpha
significant debugging and implementation help on wc_find_or_insert, wc_dict_find_or_insert
implementation and debugging of main in c
compare implementation and debugging, isspace in assembly