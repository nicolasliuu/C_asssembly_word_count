TODO: add information about contributions of team member(s)
